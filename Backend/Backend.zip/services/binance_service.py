from datetime import datetime,timedelta
from binance.spot import Spot as Client
import requests
from services.redis_service import RedisService
import json
from services.coingecko_service import CoinGeckoService
from db.db_handler import DatabaseHandler
import asyncio
import aiohttp
UNSUPPORTED_ASSETS = set()

class BinanceService:
    def __init__(self, api_key=None, api_secret=None):
        # self.client = Client(api_key, api_secret)
        self.client = Client(api_key, api_secret) if api_key and api_secret else None
        self.redis_client = RedisService.get_client()

    @staticmethod
    def convert_timestamp(raw_timestamp):
        """
        Converts a Binance timestamp (milliseconds) into a MySQL-compatible datetime format.

        Parameters:
        - raw_timestamp: The timestamp from Binance (int, string, or preformatted).

        Returns:
        - A formatted timestamp (YYYY-MM-DD HH:MM:SS) or None if invalid.
        """
        try:
            print(f"🟡 Raw timestamp received: {raw_timestamp}")  # Debugging

            if not raw_timestamp:
                print(f"❌ Skipping conversion: raw_timestamp is None or empty")
                return None  

            # ✅ If it's already in the correct format, return it
            if isinstance(raw_timestamp, str):
                try:
                    # Check if it matches the expected format
                    parsed_time = datetime.strptime(raw_timestamp, "%Y-%m-%d %H:%M:%S")
                    print(f"✅ Timestamp already in correct format: {parsed_time}")
                    return raw_timestamp
                except ValueError:
                    pass  # Not in expected format, continue to other checks

            # ✅ If it's an integer (milliseconds), convert it
            if isinstance(raw_timestamp, int) or (isinstance(raw_timestamp, str) and raw_timestamp.isdigit()):
                converted_time = datetime.utcfromtimestamp(int(raw_timestamp) / 1000).strftime('%Y-%m-%d %H:%M:%S')
                print(f"✅ Converted timestamp (int/ms): {converted_time}")
                return converted_time

        except Exception as e:
            print(f"❌ Error converting timestamp: {raw_timestamp} - {e}")
            return None  

        print(f"❌ Skipping conversion for timestamp: {raw_timestamp}")
        return None


    
    # def get_account_snapshot(self):
    #     try:
    #         return self.client.account_snapshot("SPOT")
    #     except Exception as e:
    #         print(f"Error fetching account snapshot: {e}")
    #         return {}
    
    def get_account_snapshot(self):
            cache_key = "binance:account_snapshot"
            cached_data = self.redis_client.get(cache_key)

            if cached_data:
                return json.loads(cached_data)  # ✅ Return cached data if available

            response = self.client.account_snapshot(type="spot")

            # ✅ Cache the result in Redis for 60 seconds
            self.redis_client.setex(cache_key, 60, json.dumps(response))

            return response
        
    def get_trade_history(self, symbol):
        try:
            return self.client.my_trades(symbol=symbol)
        except Exception as e:
            print(f"Error fetching trade history for {symbol}: {e}")
            return []

    # def get_coin_price(self, coin):
    #     try:
    #         timestamp = int(datetime.timestamp(datetime.utcnow()) * 1000)
    #         candles = self.client.klines(
    #             symbol=f"{coin}USDT",
    #             interval="1m",
    #             startTime=timestamp,
    #             endTime=timestamp + 60000,
    #         )
    #         if candles:
    #             return float(candles[0][1])  # Open price
    #         return 0
    #     except Exception as e:
    #         print(f"Error fetching price for {coin}: {e}")
    #         return 0


    # @staticmethod
    # def get_coin_price(asset, price_type="current"):
    #     """
    #     Fetch the price of an asset from Binance, falling back to CoinGecko.
    #     If both fail, returns None so the asset can be ignored.

    #     Parameters:
    #     - asset: The asset name (e.g., BTC).
    #     - price_type: Type of price to fetch.
    #       - "current" (default): Fetch the latest trading price.
    #       - "yesterday": Fetch the previous day's closing price.

    #     Returns:
    #     - The price as a float, or None if not found.
    #     """
    #     try:
    #         # Try fetching from Binance
    #         if price_type == "current":
    #             url = f'https://api.binance.com/api/v3/ticker/price?symbol={asset}USDT'
    #         elif price_type == "yesterday":
    #             url = f'https://api.binance.com/api/v3/ticker/24hr?symbol={asset}USDT'
    #         else:
    #             raise ValueError(f"Invalid price_type '{price_type}'. Use 'current' or 'yesterday'.")

    #         response = requests.get(url)
    #         if response.status_code == 400:
    #             print(f"Warning: {asset} is not available on Binance. Trying CoinGecko.")
    #             # return CoinGeckoService.get_price(asset)  # Now calls CoinGecko

    #         response.raise_for_status()
    #         data = response.json()
    #         return float(data['price']) if price_type == "current" else float(data['prevClosePrice'])

    #     except Exception as e:
    #         print(f"Error fetching {price_type} price for {asset}: {e}")
    #         # return CoinGeckoService.get_price(asset)  # Now calls CoinGecko

    def get_all_prev_close_prices(self):
        """
        Fetches the previous close prices for all USDT trading pairs from Binance in a single request and caches them.
        
        Returns:
        - A dictionary of previous close prices, e.g., {"BTC": 32000, "ETH": 2200, ...}
        """
        try:
            # Check Redis cache
            cached_prices = self.redis_client.get("binance_prev_close_prices")
            if cached_prices:
                return json.loads(cached_prices)

            # Fetch from Binance API (24hr ticker endpoint)
            url = 'https://api.binance.com/api/v3/ticker/24hr'
            response = requests.get(url)
            response.raise_for_status()
            data = response.json()

            # Build dictionary for assets ending with 'USDT'
            price_dict = {
                item["symbol"].replace("USDT", ""): float(item["prevClosePrice"])
                for item in data if item["symbol"].endswith("USDT")
            }

            # Cache for 60 seconds
            self.redis_client.setex("binance_prev_close_prices", 60, json.dumps(price_dict))

            return price_dict
        except Exception as e:
            print(f"Error fetching bulk previous close prices from Binance: {e}")
            return {}

    def get_all_prices(self):
        """
        Fetches all Binance USDT prices in a single request and caches them.

        Returns:
        - A dictionary of asset prices, e.g., {"BTC": 100000, "ETH": 2200}.
        """
        try:
            # Check Redis cache
            cached_prices = self.redis_client.get("binance_prices")
            if cached_prices:
                return json.loads(cached_prices)

            # Fetch from Binance API
            url = 'https://api.binance.com/api/v3/ticker/price'
            response = requests.get(url)
            response.raise_for_status()
            prices = response.json()

            # Convert to dictionary { "BTC": 32000, "ETH": 2200, ... }
            price_dict = {item["symbol"].replace("USDT", ""): float(item["price"]) for item in prices if item["symbol"].endswith("USDT")}

            # Cache for 60 seconds
            self.redis_client.setex("binance_prices", 60, json.dumps(price_dict))

            return price_dict
        except Exception as e:
            print(f"Error fetching bulk prices from Binance: {e}")
            return {}

    def get_price_from_cache(self, asset):
        """
        Gets a coin's price from Redis cache or fetches from Binance if missing.

        Parameters:
        - asset: The asset name (e.g., BTC).

        Returns:
        - The price of the asset as a float, or None if not found.
        """
        try:
            # Check if prices are cached
            cached_prices = self.redis_client.get("binance_prices")
            if cached_prices:
                price_dict = json.loads(cached_prices)
                return price_dict.get(asset, None)

            # Fetch new prices if not in cache
            price_dict = self.get_all_prices()
            return price_dict.get(asset, None)

        except Exception as e:
            print(f"Error getting cached price for {asset}: {e}")
            return None

    @staticmethod
    def calculate_average_entry_price(transactions):
        total_coins = 0
        total_usd_paid = 0

        for transaction in transactions:
            action = transaction['isBuyer']
            amount = float(transaction['qty'])
            price = float(transaction['price'])

            if action:  # If the transaction is a buy
                total_coins += amount
                total_usd_paid += amount * price
            else:  # If the transaction is a sell
                # Adjust the total USD paid based on the proportion of coins sold
                if total_coins > 0:
                    average_price_before_sale = total_usd_paid / total_coins
                    usd_value_of_sold_coins = amount * average_price_before_sale
                    total_usd_paid -= usd_value_of_sold_coins
                    total_coins -= amount

        return total_usd_paid / total_coins if total_coins > 0 else 0  # Avoid division by zero

    def check_average_price(self, asset):
        try:
            transactions = self.client.my_trades(symbol=f"{asset}USDT")
            # Convert transactions to a list of dictionaries
            formatted_transactions = [{
                'isBuyer': tx['isBuyer'],
                'qty': tx['qty'],
                'price': tx['price']
            } for tx in transactions]

            # Calculate the average entry price
            avg_price = self.calculate_average_entry_price(formatted_transactions)
            print(f"✅ Average Entry Price for {asset}: {avg_price}")
            return avg_price

        except Exception as e:
            print(f"Error fetching transactions for {asset}: {e}")
            return 0  # Default to 0 if no trade history is available


    @staticmethod
    def get_withdrawals_for_period(client, start_time, end_time):
        """Fetches withdrawals from Binance for a specific period."""
        limit = 1000
        start_time_ms = int(start_time.timestamp() * 1000)
        end_time_ms = int(end_time.timestamp() * 1000)

        try:
            response = client.withdraw_history(
                startTime=start_time_ms, endTime=end_time_ms, limit=limit
            )
            return response if response else []
        except Exception as e:
            print(f"Error fetching withdrawals: {e}")
            return []

    @staticmethod
    def get_deposits_for_period(client, start_time, end_time):
        """Fetches deposits from Binance for a specific period."""
        limit = 1000
        start_time_ms = int(start_time.timestamp() * 1000)
        end_time_ms = int(end_time.timestamp() * 1000)

        try:
            response = client.deposit_history(
                startTime=start_time_ms, endTime=end_time_ms, limit=limit
            )
            return response if response else []
        except Exception as e:
            print(f"Error fetching deposits: {e}")
            return []

    

    @staticmethod
    def get_transactions_for_period(user_id: int, api_key: str, api_secret: str, start_date: str = None, end_date: str = None):
        """
        Fetches and stores Binance withdrawals & deposits for a user in a given period.

        Parameters:
        - user_id (int): The ID of the user.
        - api_key (str): Binance API Key.
        - api_secret (str): Binance API Secret.
        - start_date (str, optional): Start date in `YYYY-MM-DD` format. Default: 2 years ago.
        - end_date (str, optional): End date in `YYYY-MM-DD` format. Default: Today.
        """

        client = Client(api_key, api_secret)  # Initialize Binance Client
        db_handler = DatabaseHandler()  # Initialize DatabaseHandler inside

        # Convert date strings to datetime objects, default to last 2 years if None
        end_time = datetime.strptime(end_date, "%Y-%m-%d") if end_date else datetime.now()
        start_time = datetime.strptime(start_date, "%Y-%m-%d") if start_date else end_time - timedelta(days=730)

        all_withdrawals = []
        all_deposits = []

        while start_time < end_time:
            next_end_time = min(start_time + timedelta(days=90), end_time)

            withdrawals = BinanceService.get_withdrawals_for_period(client, start_time, next_end_time)
            deposits = BinanceService.get_deposits_for_period(client, start_time, next_end_time)

            all_withdrawals.extend(withdrawals)
            all_deposits.extend(deposits)

            start_time = next_end_time  # Move to next period

        # Store data in MySQL using `insert_transaction_if_not_exists`
        BinanceService.store_binance_transactions(db_handler, user_id, all_withdrawals, "WITHDRAW")
        BinanceService.store_binance_transactions(db_handler, user_id, all_deposits, "DEPOSIT")

        return {
            "withdrawals": all_withdrawals,
            "deposits": all_deposits
        }



    # @staticmethod
    # def store_binance_transactions(db_handler, user_id: int, transactions, transaction_type):
    #     """
    #     Store Binance withdrawals or deposits using `insert_transaction_if_not_exists`.

    #     Parameters:
    #     - db_handler: Instance of `DatabaseHandler` to interact with the database.
    #     - user_id: ID of the user making the transactions.
    #     - transactions: List of transactions from Binance API.
    #     - transaction_type: Either 'WITHDRAW' or 'DEPOSIT'.
    #     """
    #     for tx in transactions:
    #         username = db_handler.get_username_by_user_id(user_id)
    #         if not username:
    #             print(f"Skipping transaction {tx.get('txId')} - Username not found.")
    #             continue  # Skip if username not found

    #         asset_name = tx.get("coin")
    #         amount = float(tx.get("amount", 0))
    #         # Convert timestamps safely
    #         try:
    #             timestamp = (
    #                 int(float(tx.get("applyTime", "0")) / 1000)
    #                 if "applyTime" in tx and tx.get("applyTime").isdigit()
    #                 else int(float(tx.get("insertTime", "0")) / 1000)
    #                 if "insertTime" in tx and tx.get("insertTime").isdigit()
    #                 else None
    #             )
    #         except Exception as e:
    #             print(f"Error converting timestamp for transaction {tx.get('txId')}: {e}")
    #             timestamp = None

    #         if not timestamp:
    #             print(f"Skipping transaction {tx.get('txId')} due to invalid timestamp")
    #             continue

    #         price = None  # Withdrawals/Deposits usually don’t have a direct price
    #         commission = float(tx.get("transactionFee", 0)) if tx.get("transactionFee") else 0

    #         db_handler.insert_transaction_if_not_exists(
    #             username=username,
    #             asset_name=asset_name,
    #             time=datetime.utcfromtimestamp(timestamp),
    #             quantity=amount,
    #             price=price,
    #             action=transaction_type,  # "WITHDRAW" or "DEPOSIT"
    #             commission=commission
    #         )

    #     print(f"✅ Successfully stored {len(transactions)} {transaction_type} transactions.")
        
    @staticmethod
    def store_binance_transactions(db_handler, user_id: int, transactions, transaction_type):
        """
        Store Binance withdrawals or deposits in the database.
        If an asset is not found, it is automatically added or updated.

        Parameters:
        - db_handler: Database handler instance.
        - user_id: ID of the user making the transactions.
        - transactions: List of transactions from Binance API.
        - transaction_type: Either 'WITHDRAW' or 'DEPOSIT'.
        """
        for tx in transactions:
            asset_name = tx.get("coin")  # Asset symbol (e.g., BTC, ETH)
            amount = float(tx.get("amount", 0))
            timestamp = BinanceService.convert_timestamp(tx.get("insertTime") or tx.get("applyTime"))

            if not timestamp:
                print(f"⚠️ Skipping transaction {tx.get('txId')} due to invalid timestamp ({tx.get('insertTime')})")
                continue

            # 🔹 Use insert_or_update_asset() to ensure the asset exists in the database
            avg_price = 0  # Deposits & withdrawals typically don't have a price
            db_handler.insert_or_update_asset(user_id, asset_name, amount, avg_price)

            # Fetch the AssetID after ensuring it exists
            asset_id = db_handler.get_asset_id(asset_name)
            username = db_handler.get_username_by_user_id(user_id)

            if not asset_id:
                print(f"⚠️ Skipping transaction {tx.get('txId')} - Failed to retrieve asset {asset_name}.")
                continue

            # 🔹 Check if the transaction already exists before inserting
            if db_handler.transaction_exists(asset_name, user_id, timestamp, amount):
                print(f"🔄 Transaction already exists: {tx.get('txId')} - Skipping duplicate entry.")
                continue

            # 🔹 Insert the transaction into the database
            try:
                db_handler.insert_transaction_if_not_exists(
                    asset_name=asset_name,
                    username=username,
                    time=timestamp,
                    quantity=amount,
                    price=0,  # Withdrawals & deposits usually don't have a price
                    action=transaction_type,
                    commission=0  # Default commission to 0
                )
                print(f"✅ Stored {transaction_type} transaction for {asset_name}: {amount} units")
            except Exception as e:
                print(f"❌ Error storing {transaction_type} transaction: {e}")





    #Parallel
    @staticmethod
    def get_asset_daily_balance(asset: str, amount: float, days: int):
        """
        Retrieve daily candlestick data for the given asset over the past `days` days using Binance's API,
        and compute the daily USD value by multiplying the closing price by the given amount.
        
        Returns:
            A dictionary mapping each date (YYYY-MM-DD) to the asset's USD value.
        """
        # Get daily prices: returns a list of [timestamp, close_price] pairs.
        daily_prices = BinanceService.get_daily_prices(asset, days=days)
        asset_daily_balance = {}
        for data_point in daily_prices:
            timestamp = data_point[0]  # Timestamp in milliseconds.
            date_str = datetime.utcfromtimestamp(timestamp / 1000).strftime("%Y-%m-%d")
            close_price = data_point[1]
            asset_daily_balance[date_str] = amount * close_price
        return asset_daily_balance

    @staticmethod
    def is_asset_available(asset):
        """
        Check if an asset is available on Binance by using a cached list of trading pairs.
        This list is fetched only once per day.

        Parameters:
        - asset (str): Asset symbol (e.g., 'BTC', 'ETH').

        Returns:
        - True if available, False otherwise.
        """
        try:
            redis_client = RedisService.get_client()
            cache_key = "binance_trading_pairs"

            # ✅ Step 1: Check if Binance pairs are cached in Redis
            cached_pairs = redis_client.get(cache_key)
            if cached_pairs:
                binance_symbols = set(json.loads(cached_pairs))  # Convert cached list to set
            else:
                # ❗ Step 2: Cache expired or missing → Fetch from Binance
                print("🔄 Fetching new Binance trading pairs...")
                url = "https://api.binance.com/api/v3/exchangeInfo"
                response = requests.get(url)
                response.raise_for_status()

                symbols = {s["symbol"] for s in response.json()["symbols"]}  # Convert list to set
                redis_client.setex(cache_key, 86400, json.dumps(list(symbols)))  # Cache for 1 day (86,400 sec)
                binance_symbols = symbols

            # ✅ Step 3: Check if the asset exists in Binance
            return f"{asset.upper()}USDT" in binance_symbols  # Binance pairs are uppercase

        except requests.exceptions.RequestException as e:
            print(f"⚠️ Error checking asset availability on Binance: {e}")
            return False  # Assume unavailable if API request fails
        
    @staticmethod
    async def _fetch_daily_prices_for_asset(asset: str, days: int, semaphore: asyncio.Semaphore):
        """
        Asynchronously fetch daily candlestick data for a given asset (e.g., BTC) using Binance's API.
        Returns a tuple: (asset, list of [timestamp, close_price] pairs).
        """
        symbol = f"{asset.upper()}USDT"
        # Check if the asset is available on Binance.
        if not BinanceService.is_asset_available(asset):
            print(f"Asset {asset} not available on Binance.")
            return asset, []
        
        interval = "1d"
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)
        params = {
            "symbol": symbol,
            "interval": interval,
            "startTime": int(start_time.timestamp() * 1000),
            "endTime": int(end_time.timestamp() * 1000),
            "limit": days
        }
        url = "https://api.binance.com/api/v3/klines"
        async with semaphore:
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get(url, params=params) as response:
                        response.raise_for_status()
                        data = await response.json()
                        daily_prices = []
                        for candle in data:
                            # candle format: [Open time, Open, High, Low, Close, ...]
                            timestamp = candle[0]
                            close_price = float(candle[4])
                            daily_prices.append([timestamp, close_price])
                        return asset, daily_prices
                except Exception as e:
                    print(f"Error fetching daily prices for {asset}: {e}")
                    return asset, []

    @staticmethod
    async def get_daily_prices_for_assets_parallel(assets: list, days: int, max_concurrent: int = 10):
        """
        Asynchronously fetch daily prices for a list of asset symbols concurrently.
        :param assets: List of asset symbols (e.g., ["BTC", "ETH", ...]).
        :param days: Number of days for which to fetch data.
        :param max_concurrent: Maximum number of concurrent requests.
        :return: Dictionary mapping asset symbol to its list of [timestamp, close_price] pairs.
        """
        semaphore = asyncio.Semaphore(max_concurrent)
        tasks = []
        for asset in assets:
            tasks.append(BinanceService._fetch_daily_prices_for_asset(asset, days, semaphore))
        results = await asyncio.gather(*tasks)
        return {asset: prices for asset, prices in results}

    @staticmethod
    def get_assets_daily_balances_parallel(assets_with_amount: list, days: int, max_concurrent: int = 10):
        """
        Synchronous wrapper that takes a list of tuples (asset, amount), fetches daily prices in parallel,
        calculates the daily USD value (amount * closing price) for each asset, and aggregates the results.
        :param assets_with_amount: List of tuples, e.g., [("BTC", 0.5), ("ETH", 2.0), ...].
        :param days: Number of days for which to fetch daily prices.
        :param max_concurrent: Maximum number of concurrent requests.
        :return: Dictionary mapping date (YYYY-MM-DD) to aggregated USD value.
        """
        # Extract asset symbols.
        asset_symbols = [asset for asset, _ in assets_with_amount]
        # Run the asynchronous function to fetch prices concurrently.
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        prices_dict = loop.run_until_complete(
            BinanceService.get_daily_prices_for_assets_parallel(asset_symbols, days, max_concurrent)
        )
        loop.close()
        # Aggregate daily USD values.
        total_daily_balance = {}
        for asset, amount in assets_with_amount:
            daily_prices = prices_dict.get(asset, [])
            for data_point in daily_prices:
                timestamp = data_point[0]
                date_str = datetime.utcfromtimestamp(timestamp / 1000).strftime("%Y-%m-%d")
                close_price = data_point[1]
                usd_value = amount * close_price
                total_daily_balance[date_str] = total_daily_balance.get(date_str, 0) + usd_value
        return total_daily_balance